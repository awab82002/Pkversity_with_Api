﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryEntities
{
    public class EntProgramDegree
    {
        public string? ProgramDegreeId { get; set; }
         public string? DegreeName { get; set; }
        public string? ProgramCategoryid { get; set; }
    }
}
