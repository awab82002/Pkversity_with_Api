﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryEntities
{
    public class EntProgramCategory
    {

        public string? ProgramCategoryId { get; set; }
        public string? CategoryName { get; set; }





    }
}
