﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryEntities
{
    public class EntPassingDSGroups
    {
        public string? PassingDSGroupsId { get; set;}
        public string? PassingDSGroups { get; set; }
        public string? PassingDegreeId { get; set; }

    }
}
