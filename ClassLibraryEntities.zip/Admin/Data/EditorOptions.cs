using System;

namespace Admin.Data
{
    public class EditorOptions
    {
        public string InitialText { get; set; }
    }
}
